package Steps;

import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass {
	
	public static ChromeDriver driver;    // need to convert in to static ow null pointer exception

}
